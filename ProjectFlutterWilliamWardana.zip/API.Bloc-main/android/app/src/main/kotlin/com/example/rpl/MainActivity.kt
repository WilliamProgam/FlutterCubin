package com.example.rpl

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
